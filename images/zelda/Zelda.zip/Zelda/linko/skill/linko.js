function getTable() {
    return `
      <TABLE class="table1" border="1" width="590" bgcolor="mintcream">
  <CAPTION>Move List</CAPTION>

    <TR bgcolor="gray">
      <TH colspan="2"><FONT size="-1" color="white">Moves</FONT></TH>
    </TR>

    <tr>
      <TD width="312"><FONT size="2">Double Tap</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/F.gif"> 
          <IMG src="gif/F.gif">
          or
          <IMG src="gif/B.gif">
          <IMG src="gif/B.gif">
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">???</FONT></TD>
      <TD width="262">
          <IMG src="gif/F.gif"> 
          <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">???</FONT></TD>
      <TD width="262">
          <IMG src="gif/U.gif"> 
          <FONT size="-1">+</FONT>
          <IMG src="gif/D.gif"> 
          <FONT size="-1">X</FONT>
          <FONT size="-1">or</FONT>
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">???</FONT></TD>
      <TD width="262">
          <IMG src="gif/F.gif"> 
          <FONT size="-1">or</FONT>
          <IMG src="gif/B.gif"> 
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">???</FONT></TD>
      <TD width="262">
          <IMG src="gif/U.gif"> 
          <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">???</FONT></TD>
      <TD width="262">
          <IMG src="gif/U.gif"> 
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">???</FONT></TD>
      <TD width="262">
          <IMG src="gif/D.gif"> 
          <FONT size="-1">Y</FONT>
          <FONT size="-1">+</FONT>
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">COMBO</FONT></TD>
      <TD width="262">
        <FONT size="-1">X</FONT>
        <FONT size="-1">X</FONT>
        <FONT size="-1">X</FONT>
        <FONT size="-1">X</FONT>
        <FONT size="-1">X</FONT>
        <FONT size="-1">+</FONT>
        <IMG src="gif/F.gif">
        <FONT size="-1">X</FONT>
        <FONT size="-1">X</FONT>
        <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi1</FONT></TD>
      <TD width="262">
          <IMG src="gif/D.gif">
          <IMG src="gif/DF.gif">
          <IMG src="gif/F.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/F.gif">
          <IMG src="gif/D.gif">
          <IMG src="gif/F.gif">
          <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi2</FONT></TD>
      <TD width="262">
          <IMG src="gif/D.gif">
          <IMG src="gif/BD.gif">
          <IMG src="gif/D.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/D.gif">
          <IMG src="gif/F.gif">
          <IMG src="gif/B.gif">
          <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi3</FONT></TD>
      <TD width="262">
          <IMG src="gif/F.gif">
          <IMG src="gif/D.gif">
          <IMG src="gif/DF.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/D.gif">
          <IMG src="gif/F.gif">
          <IMG src="gif/B.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/B.gif">
          <IMG src="gif/F.gif">
          <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi4</FONT></TD>
      <TD width="262">
          <IMG src="gif/D.gif">
          <IMG src="gif/DF.gif">
          <IMG src="gif/F.gif">
          <FONT size="-1">Y</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/D.gif">
          <IMG src="gif/F.gif">
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi5</FONT></TD>
      <TD width="262">
          <IMG src="gif/D.gif">
          <IMG src="gif/BD.gif">
          <IMG src="gif/B.gif">
          <FONT size="-1">Y</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/D.gif">
          <IMG src="gif/D.gif">
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi6</FONT></TD>
      <TD width="262">
          <IMG src="gif/F.gif">
          <IMG src="gif/D.gif">
          <IMG src="gif/DF.gif">
          <FONT size="-1">Y</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/F.gif">
          <IMG src="gif/B.gif">
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi7</FONT></TD>
      <TD width="262">
          <IMG src="gif/F.gif">
          <IMG src="gif/D.gif">
          <IMG src="gif/B.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">Y</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/B.gif">
          <IMG src="gif/D.gif">
          <IMG src="gif/B.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">ougi8</FONT></TD>
      <TD width="262">
          <IMG src="gif/B.gif">
          <IMG src="gif/D.gif">
          <IMG src="gif/F.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">Y</FONT>
          <FONT size="-1">+</FONT>
          <IMG src="gif/B.gif">
          <IMG src="gif/D.gif">
          <FONT size="-1">X</FONT>
          <FONT size="-1">Y</FONT>
      </TD>
    </tr>
</TABLE>
    `
}