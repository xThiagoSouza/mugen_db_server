function getTable() {
    return `
      <TABLE class="table1" border="1" width="590" bgcolor="mintcream">
  <CAPTION>Move List</CAPTION>

    <TR bgcolor="gray">
      <TH colspan="2"><FONT size="-1" color="white">Moves</FONT></TH>
    </TR>

    <tr>
      <TD width="312"><FONT size="2">Double Tap</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/F.gif"> 
          <IMG src="gif/F.gif">
          or
          <IMG src="gif/B.gif">
          <IMG src="gif/B.gif">
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">GigaJump</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <IMG src="gif/U.gif">
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">???</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <FONT size="-1">+</FONT>
          <FONT size="-1">A</FONT>          
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Arc</FONT></TD>
      <TD width="262">
        <FONT size="-1">A</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Boomerang</FONT></TD>
      <TD width="262">
        <FONT size="-1">B</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Grappin</FONT></TD>
      <TD width="262">
        <FONT size="-1">C</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">Z</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Bombe</FONT></TD>
      <TD width="262">
        <FONT size="-1">X</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Bombe delay</FONT></TD>
      <TD width="262">
        <FONT size="-1">A</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">B</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Baguette de feu</FONT></TD>
      <TD width="262">
        <FONT size="-1">Y</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">Z</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Baguette de glace</FONT></TD>
      <TD width="262">
        <FONT size="-1">B</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">C</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Multi-Slash</FONT></TD>
      <TD width="262">
        <FONT size="-1">X</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">X</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">X</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Boule Kokiri</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <IMG src="gif/DF.gif">
          <IMG src="gif/F.gif">
        </FONT>+
        <FONT size="-1">X</FONT>
        <FONT size="-1">or</FONT>
        <FONT size="-1">Y</FONT>
        <FONT size="-1">or</FONT>
        <FONT size="-1">Z</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Tournante</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <IMG src="gif/BD.gif">
          <IMG src="gif/B.gif">
        </FONT>+
        <FONT size="-1">X</FONT>
        <FONT size="-1">or</FONT>
        <FONT size="-1">Y</FONT>
        <FONT size="-1">or</FONT>
        <FONT size="-1">Z</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Teleport</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <IMG src="gif/BD.gif">
          <IMG src="gif/B.gif">
        </FONT>+
        <FONT size="-1">A</FONT>
        <FONT size="-1">or</FONT>
        <FONT size="-1">B</FONT>
        <FONT size="-1">or</FONT>
        <FONT size="-1">C</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Mushu</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <IMG src="gif/DF.gif">
          <IMG src="gif/F.gif">
        </FONT>+
        <FONT size="-1">A</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">B</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">C</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Invisibilite</FONT></TD>
      <TD width="262">
          <IMG src="gif/D.gif">
          <IMG src="gif/D.gif">
          <IMG src="gif/D.gif">
        <FONT size="-1">+</FONT>
        <FONT size="-1">START</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Chanson du temps</FONT></TD>
      <TD width="262">
          <IMG src="gif/B.gif">
          <IMG src="gif/F.gif">
        <FONT size="-1">+</FONT>
        <FONT size="-1">START</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Danse des illusions</FONT></TD>
      <TD width="262">
          <IMG src="gif/B.gif">
          <IMG src="gif/F.gif">
        <FONT size="-1">+</FONT>
        <FONT size="-1">X</FONT>
      </TD>
    </tr>

    <TR bgcolor="gray">
      <TH colspan="2"><FONT size="-1" color="white">Special Moves</FONT></TH>
    </TR>

    <tr>
      <TD width="312"><FONT size="2">Onde Kokiri</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <IMG src="gif/DF.gif">
          <IMG src="gif/F.gif">
        </FONT>+
        <FONT size="-1">X</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">Y</FONT>
      </TD>
    </tr>

    <tr>
      <TD width="312"><FONT size="2">Biggoron Scombo</FONT></TD>
      <TD width="262">
        <FONT size="-1">
          <IMG src="gif/D.gif">
          <IMG src="gif/BD.gif">
          <IMG src="gif/B.gif">
        </FONT>+
        <FONT size="-1">X</FONT>
        <FONT size="-1">+</FONT>
        <FONT size="-1">Y</FONT>
      </TD>
    </tr>
</TABLE>
    `
}