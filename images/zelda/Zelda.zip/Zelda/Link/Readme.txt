Link v0.7 (environ) par RMX et Silencer. Si vous lisez ce fichier, vous savez d�j� ke cette 
version est une b�ta priv�e et k'il serait souhaitable k'elle le reste.

Juste pour pr�ciser, certains sprites proviennent d'autres persos(les sparks de la boule et 
de l'onde, certaines fum�es, Baitang et l'effet de la tournante), Sepher & Misamu sont ok, 
N64Mario n'a pas encore r�pondu de son cot� (m� vu ke cette release est priv�e, l'effet est 
kan m�me pr�sent).


Legende : B = Arri�re, D = Bas, F = Avant, U = Haut, S = Start
          P = Poing, LP = Poing faible, MP = Poing moyen, HP = Poing fort
          K = Pied, LK = Pied faible, MK = Pied moyen, HK = Pied fort


Le gameplay de Link est majoritairement bas� sur les s�ries Marvel vs Capcom. Il est donc 
conseill� d'utiliser ce perso sur des stages � haut scrolling.


* Abilit�s : 

- Petit saut :
  U bri�vement

- Gigasaut :
  D, U

- Parade :
  F juste avant de se faire frapper pour parer les coups ki se blokent en garde haute; D 
  pour parer les coups ki se blokent en garde basse.
  Permet de ne pas subir les d�gats de garde et laisse l'adversaire vuln�rable � une 
  contre-attak imm�diate.

- Roulade :
  FF ou BB kan Link est � terre pour se relever en roul�.

- Empaleur :
  DF+LP � cot� d'un ennemi � terre.

- KO(pas franchement une abilit� m� j'savais pas o� le mentionner) :
  Suffit de se prendre suffisamment de coups dans un laps de temps pour y avoir droit...


* Objets : 

- Arc :
  LP+LK
  Maintenez ces touches enfonc�es pour ne pas d�cocher de suite la fl�che, maintenez D pour 
  s'accroupir.

- Boomerang :
  MP+MK
  Maintenez D ou U avant de le lancer pour choisir la direction.
  
- Bombe :
  LP+MP
  Autant nocive pour Link ke pour son adversaire...
  Maintenez B ou F avant de la lancer pour choisir la port�e.

- Bombe � retardement :
  LK+MK
  Toujours aussi nocive et peut en prime �tre renvoy�e dans la tronche du lanceur m� cette 
  version est imblocable.
  Maintenez B ou F avant de la lancer pour choisir la port�e.

- Grappin :
  HP+HK

- Baguette de feu :
  MP+HP

- Baguette de glace :
  MK+HK


* Coups sp�ciaux : 

- Multi-Slash :
  LP � r�p�tition
  Maintenez D pour s'accroupir.

- Boule Kokiri :
  D, DF, F, P

- Tournante : 
  D, DB, B, P
  Pressez B ou F durant les 1ers ticks de la version MP (F pour la version HP) afin de se 
  d�placer.

- Teleport :
  D, DB, B, K
  Maintenez HK dans la version HK pour prolonger le trajet jusk'au bout de l'�cran au 
  maximum.

- Invisibilit� :
  D, D, D, S

- Mushu :
  D, DF, F, K


* Supers : 

- Onde Kokiri :
  D, DF, F, 2P

- Biggoron Scombo :
  D, DB, B, 2P
  (QTC signifie "Quick Time Counter" pour la petite histoire)

- Chanson du temps :
  B, F, S

- Danse des illusions :
  B, F, P
